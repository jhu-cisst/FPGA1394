These files contain the necessary information to assemble a PCB.

Board Name: IEEE-1394/Ethernet FPGA Board, Rev 2.0
Release Date: 10/13/2015 --- Original release
Release Date: 10/26/2015 --- Added items 7,8.
                             Updated pick & place files to inlude the fiducials.

The files included are:
1-  ReadME.txt       This file
2-  FPGA.GTP         Top side paste mask
3-  FPGA.GBP         Bottom side paste mask
4-  FPGA PnP.CSV     Pick & Place file in CSV format
5-  FPGA PnP.txt     Pick & Place file in Text format
6-  FPGA Assy.pdf    Assembly Drawing
7-  FPGA-FD.GTP      Top side paste mask, including the fiducials
8-  FPGA-FD.GBP      Bottom side paste mask, including the fiducials

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

2) Apertures in the paste mask are the same size as the PCB pads.

3) The CSV and txt files contain the exact same information, just
   in different formats.

4) The FPGA.GxP and FPGA-FD.GxP files are identical except that the
   "-FD" files include an opening for the fiducial pads, while the
   other files do not.
