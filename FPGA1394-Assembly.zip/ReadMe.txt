These files contain the necessary information to assemble a PCB.

Board Name: IEEE-1394 FPGA Board, Rev 1.2
Release Date: 06/14/2013

The files included are:
1-  ReadME.txt       This file
2-  FPGA.GTP         Top side paste mask
3-  FPGA.GBP         Bottom side paste mask
4-  FPGA PnP.CSV     Pick & Place file in CSV format
5-  FPGA PnP.txt     Pick & Place file in Text format
6-  FPGA Assy.pdf    Assembly Drawing

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

2) Apertures in the paste mask are the same size as the PCB pads.

3) The CSV and txt files contain the exact same information, just
   in different formats.
