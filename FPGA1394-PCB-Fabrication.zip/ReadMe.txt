These files contain the necessary information to manufacture
a printed circuit board.

Board Name: IEEE-1394 FPGA Board, Rev 1
Release Date: 05/20/2010

The files included are:
1-  ReadME.txt       This file
2-  FPGA.GTL         Top side routing layer
3-  FPGA.GBL         Bottom side routing layer
4-  FPGA.GP1         Internal Plane 1
5-  FPGA.GP2         Internal Plane 2
6-  FPGA.GP3         Internal Plane 3
7-  FPGA.G1          Internal Layer 1
8-  FPGA.GTO         Top side silk screen mask
9-  FPGA.GBO         Bottom side silk screen mask
10- FPGA.GTS         Top side solder mask
11- FPGA.GBS         Bottom side solder mask
12- FPGA.DRL         Excellon drill file
13- FPGA-Holes.TXT   Text of drill file for holes
14- FPGA-Slots.TXT   Text of drill file for slots
15- FPGA.IPC         IPC-D-356A Netlist
16- FPGA.PDF         Drill and fabrication drawing

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

FAB INSTRUCTIONS:
- Vendor and process shall be UL 94V-0 approved.
- Boards must be marked with vender identification and UL 94V-0
- Material: FR4
- Vias: Top-Bottom only.
- Solder mask: LPI   Color: green
- Silkscreen on both sides. Color: white
- Fab tolerance:  See fabrication drawing
- Layer Sequence: See fabrication drawing
- Copper Weight:  See fabrication drawing
- Thickness:      See fabrication drawing
